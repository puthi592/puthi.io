/* CP-AI install banner + service worker. Self-contained: no IDs needed. */
(function () {
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', function () {
      navigator.serviceWorker.register('/sw.js').catch(function () {});
    });
  }

  var isStandalone =
    window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone;
  if (isStandalone) return;

  var deferredPrompt = null;
  var DISMISS_KEY = 'cpai-install-dismissed';

  function dismissed() {
    try { return Date.now() - Number(localStorage.getItem(DISMISS_KEY) || 0) < 3 * 86400000; }
    catch (e) { return false; }
  }

  function buildBanner(content) {
    var bar = document.createElement('div');
    bar.id = 'cpai-install-bar';
    bar.style.cssText =
      'position:fixed;left:0;right:0;bottom:0;z-index:99999;display:flex;align-items:center;' +
      'justify-content:center;gap:14px;padding:12px 16px calc(12px + env(safe-area-inset-bottom));' +
      'background:#071a2e;border-top:1px solid #14395f;color:#fff;font-family:system-ui,sans-serif;' +
      'box-shadow:0 -6px 24px rgba(0,0,0,.45);';
    bar.innerHTML =
      '<img src="/icon-192.png" alt="" style="width:44px;height:44px;border-radius:12px">' +
      '<div style="line-height:1.25"><div style="font-weight:700">Install CP-AI</div>' +
      '<div style="font-size:13px;opacity:.8">' + content.sub + '</div></div>' +
      (content.btn ? '<button id="cpai-install-btn" style="background:#3b82f6;color:#fff;border:0;' +
        'padding:10px 22px;border-radius:999px;font-weight:600;font-size:15px;cursor:pointer">Install</button>' : '') +
      '<button id="cpai-install-x" aria-label="Close" style="background:none;border:0;color:#fff;' +
      'font-size:22px;cursor:pointer;opacity:.8">✕</button>';
    document.body.appendChild(bar);

    document.getElementById('cpai-install-x').onclick = function () {
      bar.remove();
      try { localStorage.setItem(DISMISS_KEY, String(Date.now())); } catch (e) {}
    };
    var btn = document.getElementById('cpai-install-btn');
    if (btn) {
      btn.onclick = function () {
        if (!deferredPrompt) return;
        deferredPrompt.prompt();
        deferredPrompt.userChoice.then(function () {
          deferredPrompt = null;
          bar.remove();
        });
      };
    }
  }

  // Android / Desktop Chrome, Edge
  window.addEventListener('beforeinstallprompt', function (e) {
    e.preventDefault();
    deferredPrompt = e;
    if (dismissed() || document.getElementById('cpai-install-bar')) return;
    buildBanner({ sub: 'Use it like an app on your device', btn: true });
  });

  window.addEventListener('appinstalled', function () {
    var b = document.getElementById('cpai-install-bar');
    if (b) b.remove();
  });

  // iPhone / iPad Safari has no install event: show manual steps
  var isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent);
  if (isIOS && !dismissed()) {
    window.addEventListener('load', function () {
      buildBanner({ sub: 'Tap Share, then “Add to Home Screen”', btn: false });
    });
  }
})();
